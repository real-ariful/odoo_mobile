# -*- coding: utf-8 -*-
from odoo import http

# class Requisition(http.Controller):
#     @http.route('/requisition/requisition/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/requisition/requisition/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('requisition.listing', {
#             'root': '/requisition/requisition',
#             'objects': http.request.env['requisition.requisition'].search([]),
#         })

#     @http.route('/requisition/requisition/objects/<model("requisition.requisition"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('requisition.object', {
#             'object': obj
#         })