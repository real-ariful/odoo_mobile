# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.addons import decimal_precision as dp 


class requisition(models.Model):

	_name = 'requisition.requisition'

	_description = 'Requisition' 
	_order = 'sequence desc'
	_rec_name = 'sequence'



	REQUISITION_STATE = [
	            ('draft', 'Draft'),
	            ('approve', 'Sent to RFQ'),
	            ('done', 'Send to PO'),
	            ('cancel', 'Cancelled'),
	            ]

	#Function for 'Approve' Button Clicked


	def approve_confirm(self):
		import datetime


		for rec in self:
			if not rec.order_id:
				rec.state = 'approve'


				                    
				order_id = self.env["purchase.order"].create({"partner_id":7}) 
				order_lines = self.env["purchase.order.line"].create(
				{
				"date_planned": datetime.date.today(),
				"product_qty": self.product_qty, 
				"order_id":order_id.id,
				"product_id": self.product_id.id, 

				"price_unit": 500,
				"product_uom": self.product_id.uom_id.id, 
				"name":"hishu","product_qty":1            
				})
				self.order_id = order_id.id
				#self.sequence = self.id
			else:
			    raise AssertionError

	#Function for 'Cancel' Button Clicked
	def cancel_confirm(self):
		for rec in self:
			if not rec.order_id:
			    rec.state = 'cancel'


	
	@api.depends('sequence')	
	def _get_requisition_id(self):
		#import pdb; pdb.set_trace()
		for rec in self:
			rec.sequence = rec[-1].id + 1

	#---------------Requiremnets for product----------
	product_id = fields.Many2one('product.product', string='Product',required=True)
	product_qty = fields.Integer('Requisition Quantity', default = 1, required=True)

	order_id = fields.Char(string='')


	unit_ofmeasure = fields.Many2one('uom.uom', string='Unit of Measure',related="product_id.uom_id")  
	delivery_date = fields.Date('Delivery Date', required=True)

	stock_location = fields.Many2one( 'stock.warehouse', string='Stock Location', required=True)
	#sequence = fields.Char('Name')
	sequence = fields.Integer(compute='_get_requisition_id', string='Name', readonly=True)

	state = fields.Selection(REQUISITION_STATE,default='draft', string='Status', readonly=True)
